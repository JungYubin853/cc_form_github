<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\LEGION\Herd\cloud_computing_form\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>