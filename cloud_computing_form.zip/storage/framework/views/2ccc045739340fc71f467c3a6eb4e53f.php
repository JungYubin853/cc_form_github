
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contact Form</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <style>
        body {
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
            margin: 0;
            padding: 24px;
            background: #fcfdfd;
            color: #1b1b18;
        }

        .container {
            max-width: 640px;
            margin: 0 auto;
        }

        .card {
            background: rgb(216, 216, 216);
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.07);
        }

        label {
            display: block;
            font-weight: 600;
            margin: 14px 0 6px;
        }

        input,
        textarea {
            width: 95%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 10px;
            font-size: 16px;
        }

        button {
            margin-top: 18px;
            padding: 12px 18px;
            border: 0;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            background: #111;
            color: #fff;
        }

        .error {
            color: #b00020;
            font-size: 14px;
            margin-top: 6px;
        }

        .flash {
            background: #e8fff0;
            color: #0a6b2b;
            border: 1px solid #b6f2cc;
            padding: 10px 14px;
            border-radius: 10px;
            margin-bottom: 16px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Contact Form</h1>

        <?php if(session('success')): ?>
            <div class="flash"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="card">
            <form method="POST" action="<?php echo e(route('contact.store')); ?>">
                <?php echo csrf_field(); ?>

                <label for="name">Full Name</label>
                <input id="name" name="name" type="text" value="<?php echo e(old('name')); ?>" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label for="email">Email</label>
                <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" required>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label for="subject">Subject</label>
                <input id="subject" name="subject" type="text" value="<?php echo e(old('subject')); ?>" required>
                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label for="message">Message</label>
                <textarea id="message" name="message" rows="6" required><?php echo e(old('message')); ?></textarea>
                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <button type="submit">Send</button>
            </form>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\Users\LEGION\Herd\cloud_computing_form\resources\views/welcome.blade.php ENDPATH**/ ?>