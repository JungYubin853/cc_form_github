<?php $__env->startComponent('mail::message'); ?>
# New Contact Message

**From:** <?php echo new \Illuminate\Support\EncodedHtmlString($data['name']); ?>  
**Email:** <?php echo new \Illuminate\Support\EncodedHtmlString($data['email']); ?>  
**Subject:** <?php echo new \Illuminate\Support\EncodedHtmlString($data['subject']); ?>


---

<?php echo new \Illuminate\Support\EncodedHtmlString($data['message']); ?>


<?php $__env->startComponent('mail::panel'); ?>
Sent via <?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\LEGION\Herd\cloud_computing_form\resources\views/emails/contact/message.blade.php ENDPATH**/ ?>