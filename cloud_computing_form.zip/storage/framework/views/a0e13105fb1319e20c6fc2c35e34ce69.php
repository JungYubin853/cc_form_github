<?php echo e($slot); ?>

<?php /**PATH C:\Users\LEGION\Herd\cloud_computing_form\resources\views/vendor/mail/text/panel.blade.php ENDPATH**/ ?>