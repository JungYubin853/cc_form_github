@component('mail::message')
# New Contact Message

**From:** {{ $data['name'] }}  
**Email:** {{ $data['email'] }}  
**Subject:** {{ $data['subject'] }}

---

{{ $data['message'] }}

@component('mail::panel')
Sent via {{ config('app.name') }}
@endcomponent
@endcomponent
